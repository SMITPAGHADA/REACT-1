import React from 'react'

function About() {
  return (
    <>
     <div className="about w-full h-[86.2vh] bg-black text-white px-[200px]">

        <h1 className='text-[40px] text-center pt-[100px]'>About Us</h1>

        <p className='text-center'>Lorem ipsum dolor sit amet consectetur adipisicing elit. Temporibus repellat rerum tempora a impedit architecto ad voluptates assumenda iusto, fugiat enim nesciunt unde? Voluptas perferendis reiciendis iste, veniam saepe amet. Lorem ipsum dolor sit amet consectetur adipisicing elit. Numquam, perspiciatis blanditiis! Esse iste sequi ipsam iusto debitis, ea eius. Temporibus autem aperiam hic possimus, veritatis natus adipisci asperiores nostrum harum. Lorem ipsum dolor, sit amet consectetur adipisicing elit. Dolores inventore eaque excepturi doloremque vel est eos? Veniam, commodi voluptatem voluptatibus nostrum eum consequuntur aperiam molestias possimus dolorem neque consequatur pariatur.</p>
        </div> 
    </>
  )
}

export default About
