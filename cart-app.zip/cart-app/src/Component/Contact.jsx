import React from 'react'

function Contact() {
  return (
    <>
     <div className="contact w-full h-[86.2vh] bg-black text-white">
            <h1 className='text-[40px] text-center pt-[180px]'>Contact Page</h1>
        </div> 
    </>
  )
}

export default Contact
